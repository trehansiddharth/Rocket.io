#!/bin/bash

cd $HOME/.snapsync
./node-snapsync snapsync.js
